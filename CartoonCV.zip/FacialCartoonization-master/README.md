﻿# White-box facial image cartoonizaiton

- Pytorch implementation of a simple facial image cartoonizaiton netowrk
- This work is an improvement based on CVPR2020 White-box cartoonizaiton paper 
- [project page](https://systemerrorwang.github.io/White-box-Cartoonization/) |   [paper](https://github.com/SystemErrorWang/White-box-Cartoonization/blob/master/paper/06791.pdf) |   [twitter](https://twitter.com/IlIIlIIIllIllII/status/1243108510423896065) |   [zhihu](https://zhuanlan.zhihu.com/p/117422157) |   [bilibili](https://www.bilibili.com/video/av56708333)

## Focus on this 
### Installation
- Install python with modify and add pip
- Install pytorch, Opencv, numpy and tqdm 
- pytorch : pip install torch
- Opencv : pip install opencv-python
- numpy: pip install opencv-python
- tqdm: pip install tqdm



### Inference with Pre-trained Model

- Run 'inference.py', output will be showed through the camera.





